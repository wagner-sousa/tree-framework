This version of SimpleMDE have a little changes for Bludit.

--- Image preview hack ---

Original
<img src="'+e+'"

Bludit hack
<img src="'+HTML_PATH_UPLOADS+e+'"


--- HTTP for HTTPS ---
Original
http://

Bludit hack
https://

--- Icons ---

fa-quote-left
oi-double-quote-serif-left

fa-list-ul
oi-list

oi-link
oi-link-intact

fa-picture-o
oi-image

fa-columns
oi-browser

fa-arrows-alt
oi-fullscreen-enter

fa fa-
oi oi-
