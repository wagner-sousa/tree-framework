<h1 align="center">Sponsors &amp; Backers</h1>

Metro 4 is an MIT-licensed open source project. 
It's an independent project with its ongoing development made possible entirely thanks to the support by these awesome Backers. 
If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/metroui)
- [Become a backer or sponsor on Open Collective](https://opencollective.com/metro4#backer)

<!--
<h2 align="center">Platinum sponsors</h2>
-->


<h2 align="center">Gold sponsors</h2>
<div align="center">
<a href="https://openbuilds.com/"><img src="https://metroui.org.ua/images/OpenBuilds_logo.png"></a>
</div>

<!--
<h4 align="center">Silver sponsors</h4>
<div align="center">
</div>
-->

<!--
<h2 align="center">Bronze via Patreon</h2>
-->

<!--
<h2 align="center">Generous Backers via Patreon ($50+)</h2>
-->

<h2 align="center">Backers via Patreon</h2>

 - [Jonathan](https://www.patreon.com/user/creators?u=10019621) 
 - [Arnaud Dagnelies](https://www.patreon.com/user/creators?u=13947239)


<hr>
 
Thanks to all who [supported a project](DONORS.md)